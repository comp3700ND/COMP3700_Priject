We used MySQL database and it is stored as store.sql.

YOu can find all of our project files in the checkout termianl folder in the src folder.

We also provided a word document with all of our use case analysis and screen shots.