import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.sql.Date;
import java.util.Locale;

public class UserManagerController implements ActionListener {
    private UserScreen userView;
    private DataAdapter dataAdapter; // to save and load product information

    public UserManagerController(UserScreen us, DataAdapter dataAdapter) {
        this.dataAdapter = dataAdapter;
        this.userView = us;

        userView.getBtnLoad().addActionListener(this);

    }


    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == userView.getBtnLoad())
            loadUser();

        if (e.getSource() == userView.getBtnSave())
            saveUser();
    }


    public void loadUser() {
        String UserID = "";

        try {
            UserID = (userView.getTxtUserID().getText());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid Info Please provide a valid product ID!");
            return;
        }

        User user = dataAdapter.loadUser(UserID);

        if (user == null) {
            JOptionPane.showMessageDialog(null, "This User does not exist in the database!");
            return;
        }

        userView.getTxtUserID().setText(String.valueOf(user.getUserID()));
        userView.getTxtUserName().setText((user.getUserName()));
        userView.getTxtUserPassword().setText((user.getPassword()));
        userView.getTxtDisplayName().setText((user.getDisplayName()));
        userView.getTxtisManager().setText(String.valueOf(user.isManager()));
    }




    public void saveUser() {
        int userID;
        try {
            userID = Integer.parseInt(userView.getTxtUserID().getText());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid  ID! Please provide a valid product ID!");
            return;
        }

        String Password;

           Password = (userView.getTxtUserPassword().getText());


        String userName;
        try {
            userName = (userView.getTxtUserName().getText());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid product quantity! Please provide a valid product quantity!");
            return;
        }

        String DisplayName;
        try {
            DisplayName = (userView.getTxtDisplayName().getText());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid product TaxRate! Please provide a valid product quantity!");
            return;
        }

        String manager;
        try {
            manager = (userView.getTxtisManager().getText());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid product Vendor! Please provide a valid product quantity!");
            return;
        }


        // Done all validations! Make an object for this product!

        User user = new User();
        user.setUserID(userID);
        user.setPassword(Password);
        user.setUserName(userName);
        user.setDisplayName(DisplayName);

        boolean managervalue;

        if (manager == "1")
        {
            managervalue = true;
        }

        else {
            managervalue = false;
        }
        user.setManager(managervalue);


        // Store the product to the database

        dataAdapter.SaveUser(user);
        JOptionPane.showMessageDialog(null, "User Saved!");
    }


}

