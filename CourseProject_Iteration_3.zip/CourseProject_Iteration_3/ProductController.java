import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.sql.Date;
import java.util.Locale;

public class ProductController implements ActionListener {
    private ProductView productView;
    private DataAdapter dataAdapter; // to save and load product information

    public ProductController(ProductView productView, DataAdapter dataAdapter) {
        this.dataAdapter = dataAdapter;
        this.productView = productView;

        productView.getBtnLoad().addActionListener(this);
        productView.getBtnSave().addActionListener(this);
    }


    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == productView.getBtnLoad())
            loadProduct();
        else
        if (e.getSource() == productView.getBtnSave())
            saveProduct();
    }

    private void saveProduct() {
        int productID;
        try {
            productID = Integer.parseInt(productView.getTxtProductID().getText());
        }
        catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid product ID! Please provide a valid product ID!");
            return;
        }

        double productPrice;
        try {
            productPrice = Double.parseDouble(productView.getTxtProductPrice().getText());
        }
        catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid product price! Please provide a valid product price!");
            return;
        }

        double productQuantity;
        try {
            productQuantity = Double.parseDouble(productView.getTxtProductQuantity().getText());
        }
        catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid product quantity! Please provide a valid product quantity!");
            return;
        }

        double TaxRate;
        try {
            TaxRate = Double.parseDouble(productView.getTxtTaxRate().getText());
        }
        catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid product TaxRate! Please provide a valid product quantity!");
            return;
        }

        java.sql.Date ExpirationDate = null;
        try {
            String startDateString = ((productView.getTxtExperationDate().getText()));
            SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
            java.util.Date date = sdf1.parse(startDateString);
            ExpirationDate = new java.sql.Date(date.getTime());
            } catch (ParseException e) {
                e.printStackTrace();
            }

        catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid product Expiration Date! Please provide a valid product quantity!");
            return;
        }

        String vendorName;
        try {
            vendorName = (productView.getTxtVendorName().getText());
        }
        catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid product Vendor! Please provide a valid product quantity!");
            return;
        }

        String productName = productView.getTxtProductName().getText().trim();

        if (productName.length() == 0) {
            JOptionPane.showMessageDialog(null, "Invalid product name! Please provide a non-empty product name!");
            return;
        }

        // Done all validations! Make an object for this product!

        Product product = new Product();
        product.setID(productID);
        product.setName(productName);
        product.setPrice(productPrice);
        product.setQuantity(productQuantity);
        product.setTaxRate(TaxRate);
        product.setVendorName(vendorName);
        product.setExpirationDate(ExpirationDate);
        

        // Store the product to the database

        dataAdapter.saveProduct(product);
        JOptionPane.showMessageDialog(null, "Product Saved!");
    }

    private void loadProduct() {
        int productID = 0;
        try {
            productID = Integer.parseInt(productView.getTxtProductID().getText());
        }
        catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid product ID! Please provide a valid product ID!");
            return;
        }

        Product product = dataAdapter.loadProduct(productID);

        if (product == null) {
            JOptionPane.showMessageDialog(null, "This product ID does not exist in the database!");
            return;
        }

        productView.getTxtProductName().setText(product.getName());
        productView.getTxtProductPrice().setText(String.valueOf(product.getPrice()));
        productView.getTxtProductQuantity().setText(String.valueOf(product.getQuantity()));
        productView.getTxtVendorName().setText(String.valueOf(product.getVendorName()));
        productView.getTxtTaxRate().setText(String.valueOf(product.getTaxRate()));
        productView.getTxtExperationDate().setText(String.valueOf(product.getExpirationDate()));
    }


}