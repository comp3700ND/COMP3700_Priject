import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class PayScreen extends JFrame {

        private JButton btnPayCredit = new JButton("Pay with credit");
        private JButton btnPayDebit = new JButton("Pay with debit");
        private JButton btnPayCheck = new JButton("Pay with check");



        private JLabel OrderTotal = new JLabel("Total: ");

        public PayScreen() {

            this.setTitle("Checkout");
            this.setLayout(new BoxLayout(this.getContentPane(), BoxLayout.Y_AXIS));
            this.setSize(400, 600);


            JPanel panelButton = new JPanel();
            panelButton.setPreferredSize(new Dimension(400, 100));
            panelButton.add(btnPayCheck);
            panelButton.add(btnPayCredit);
            panelButton.add(btnPayDebit);
            this.getContentPane().add(panelButton);

            getBtnPayCheck().addActionListener(new ActionListener() { // when controller is simple, we can declare it on the fly
                public void actionPerformed(ActionEvent e) {
                    JOptionPane.showMessageDialog(null, "Thank you for you order");
                }
            });

            getBtnPayCredit().addActionListener(new ActionListener() { // when controller is simple, we can declare it on the fly
                public void actionPerformed(ActionEvent e) {
                    JOptionPane.showMessageDialog(null, "Thank you for you order");
                }
            });

            getBtnPayDebit().addActionListener(new ActionListener() { // when controller is simple, we can declare it on the fly
                public void actionPerformed(ActionEvent e) {
                    JOptionPane.showMessageDialog(null, "Thank you for you order");
                }
            });

        }


        public JButton getBtnPayCredit() {
            return btnPayCredit;
        }

        public JButton getBtnPayDebit() {
            return btnPayDebit;
        }

        public JButton getBtnPayCheck() {
            return btnPayCheck;
        }

        public JLabel getOrderTotal() {
            return OrderTotal;
        }

}
