import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.sql.Date;
import java.util.Locale;

public class UserController implements ActionListener {
    private LoginScreen userView;
    private DataAdapter dataAdapter; // to save and load product information

    public UserController(LoginScreen ls, DataAdapter dataAdapter) {
        this.dataAdapter = dataAdapter;
        this.userView = ls;

        userView.getBtnLogin().addActionListener(this);

    }


    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == userView.getBtnLogin())
            loadUser();
    }

    public void loadUser() {
        String UserName = "";
        String UserPassword = "";

        try {
            UserName = (userView.getTxtUserName().getText());
            UserPassword = (userView.getTxtPassword().getText());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid Infor! Please provide a valid product ID!");
            return;
        }

        User user = dataAdapter.loadUser(UserName, UserPassword);

        if (user == null) {
            JOptionPane.showMessageDialog(null, "This User does not exist in the database!");
            return;
        }

        if (user.isManager()) {
            Application.getInstance().getManagerScreen().setVisible(true);


        } else if (!user.isManager()) {
            Application.getInstance().getCheckoutScreen().setVisible(true);
        }



    }
}