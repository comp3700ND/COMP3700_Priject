-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 29, 2017 at 06:56 AM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `store`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `CustID` int(11) NOT NULL,
  `CustName` char(30) NOT NULL,
  `CustAddress` char(100) DEFAULT NULL,
  `CustPhoneNumber` char(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`CustID`, `CustName`, `CustAddress`, `CustPhoneNumber`) VALUES
(1, 'Joe', '123 Brown St, Harrisburg PA 12345', '123-456-7890'),
(2, 'Bob', '321 Orange St, Charlotte NC 54321', '321-654-0987'),
(3, 'Cooter', '743 Yellow St, New Orleans LA 74912', '798-832-0988'),
(4, 'Bary', '870 Green St, New York NY 89329', '786-877-9870'),
(5, 'Lary', '763 Pink St, Charlottesville VA 87431', '234-531-2532');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `OrderNo` int(11) NOT NULL,
  `OrderTime` date DEFAULT NULL,
  `Customer` char(30) DEFAULT NULL,
  `Total` double DEFAULT NULL,
  `PaymentType` char(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`OrderNo`, `OrderTime`, `Customer`, `Total`, `PaymentType`) VALUES
(100, '2017-09-07', 'Joe', 10.98, 'Visa'),
(102, '2017-09-08', 'Bob', 17.64, 'Visa'),
(203, '2017-09-12', 'Cooter', 38.27, 'Cash'),
(204, '2017-09-17', 'Bary', 102.81, 'MasterCard'),
(205, '2017-09-18', 'Lary', 78.63, 'Check');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `ProductID` int(11) NOT NULL,
  `ProductName` char(30) NOT NULL,
  `Price` double DEFAULT NULL,
  `Quantity` int(11) DEFAULT NULL,
  `experation` date DEFAULT NULL,
  `TaxRate` double DEFAULT NULL,
  `Vender` char(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`ProductID`, `ProductName`, `Price`, `Quantity`, `experation`, `TaxRate`, `Vender`) VALUES
(21, 'Catsup', 1.99, 99, NULL, 0, NULL),
(32, 'Crepes', 0.99, 99, NULL, 0, NULL),
(36, 'glasses', 200, 10, '2019-12-12', 0.07, 'Glass Co'),
(45, 'Rice', 2.99, 100, '2017-10-10', 0.07, 'YoungHoe Koo'),
(75, 'Kale', 3.99, 450, '2017-10-26', 0.07, 'Farmer Joe'),
(99, 'pumpkin', 5.99, 78, NULL, 0, NULL),
(101, 'Apple', 1.99, 513, '2017-09-26', 0.07, 'Farmer Joe'),
(102, 'Peanut Butter', 3, 26, '2019-12-08', 0.07, 'Skippy Co'),
(103, 'Coffee', 1.5, 75, '2022-08-07', 0.07, 'Starbucks'),
(104, 'Rice', 0.99, 100, '2033-10-08', 0.07, 'Farmer Su'),
(105, 'Almonds', 1.99, 60, '2017-10-28', 0.07, 'Farmer Dan'),
(309, 'Spinach', 3.99, 30, NULL, 0, NULL),
(403, 'Ice', 0.99, 1000, NULL, 0, NULL),
(405, 'Juice', 4, 35, NULL, 0, NULL),
(407, 'Pasta', 3.99, 100, NULL, 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `UserID` int(11) NOT NULL,
  `UserName` char(30) DEFAULT NULL,
  `Password` char(30) DEFAULT NULL,
  `DisplayName` char(30) DEFAULT NULL,
  `IsManager` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`UserID`, `UserName`, `Password`, `DisplayName`, `IsManager`) VALUES
(1, 'Manager', 'Password', 'Manager Chris', 1),
(2, 'John', '1234', 'Johnny Boy', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`CustID`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`OrderNo`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`ProductID`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`UserID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
