import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class UserScreen extends JFrame {
    private JTextField txtUserID = new JTextField(10);
    private JTextField txtUserName = new JTextField(30);
    private JTextField txtUserPassword = new JTextField(10);
    private JTextField txtDisplayName = new JTextField(10);
    private JTextField txtisManager = new JTextField(30);


    private JButton btnLoad = new JButton("Load User");
    private JButton btnSave = new JButton("Save User");

    public UserScreen() {
        this.setTitle("Product View");
        this.setLayout(new BoxLayout(this.getContentPane(), BoxLayout.PAGE_AXIS));
        this.setSize(500, 200);

        JPanel panelButton = new JPanel();
        panelButton.add(btnLoad);
        panelButton.add(btnSave);
        this.getContentPane().add(panelButton);

        JPanel panelProductID = new JPanel();
        panelProductID.add(new JLabel("User ID: "));
        panelProductID.add(txtUserID);
        txtUserID.setHorizontalAlignment(JTextField.RIGHT);
        this.getContentPane().add(panelProductID);

        JPanel panelProductName = new JPanel();
        panelProductName.add(new JLabel("User Name: "));
        panelProductName.add(txtUserName);
        this.getContentPane().add(panelProductName);

        JPanel panelProductInfo = new JPanel();
        panelProductInfo.add(new JLabel("User Password: "));
        panelProductInfo.add(txtUserPassword);
        txtUserPassword.setHorizontalAlignment(JTextField.RIGHT);

        panelProductInfo.add(new JLabel("User Display Name: "));
        panelProductInfo.add(txtDisplayName);
        txtDisplayName.setHorizontalAlignment(JTextField.RIGHT);
        this.getContentPane().add(panelProductInfo);

        JPanel panelMoreProductInfo = new JPanel();
        panelProductInfo.add(new JLabel("Is Manager: "));
        panelProductInfo.add(txtisManager);
        txtisManager.setHorizontalAlignment(JTextField.RIGHT);


        btnLoad.addActionListener(new ActionListener() { // when controller is simple, we can declare it on the fly
            public void actionPerformed(ActionEvent e) {
                Application.getInstance().getUserManagerController().loadUser();
            }
        });


    }

    public JButton getBtnLoad() {
        return btnLoad;
    }

    public JButton getBtnSave() {
        return btnSave;
    }

    public JTextField getTxtUserID() {
        return txtUserID;
    }


    public JTextField getTxtUserName() {
        return txtUserName;
    }

    public JTextField getTxtUserPassword() {
        return txtUserPassword;
    }

    public JTextField getTxtDisplayName() {
        return txtDisplayName;
    }

    public JTextField getTxtisManager() {
        return txtisManager;
    }


}


